raise ImportError("Please use `import osgeo_utils` (GDAL >= 3.3) "
                  "instead of `import osgeo.utils` (GDAL == 3.2). "
                  "For more details see GDAL RFC #78")
